// Placeholder script - this will be deleted soon, it exists purely because the
// original script URL was popular and still gets many direct visits.

throw new Error(`

    This frida-script.js script has now been replaced with a significantly
    upgraded set of scripts.

    To upgrade to this new version, please visit the GitHub repo at:
    https://github.com/httptoolkit/frida-interception-and-unpinning/

    If you'd still like to use the original script, the final version is
    available via GitHub here:
    https://github.com/httptoolkit/frida-interception-and-unpinning/tree/4d477da

    This will not be maintained in future, and is already missing many unpinning
    targets and other features from the latest version. Please don't file issues
    about any bugs or problems with this script.

`);
